package presenter.main;

public interface IMainPresenter {
    void optionSelected(String option);
}
