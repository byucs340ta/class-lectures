import java.util.*;

public class FlightStates {
	
	public int time = 0;
	public List<Flight> states = new ArrayList<Flight>();
	
}