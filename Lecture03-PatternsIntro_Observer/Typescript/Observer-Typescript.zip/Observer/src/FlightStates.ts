
import { Flight } from './Flight';

export class FlightStates {
	
	public time: number = 0;
	public states: Flight[] = [];
	
}