
import { FlightFeed } from './FlightFeed';

console.log("Starting Flight Monitor");

let feed = new FlightFeed();
feed.start();
