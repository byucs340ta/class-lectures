

public enum Justification {	Left, Center, Right }
