

export interface Writer {

	append(str: string): void;
}
